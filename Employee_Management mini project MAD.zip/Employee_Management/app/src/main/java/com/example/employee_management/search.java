package com.example.employee_management;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class search extends AppCompatActivity {

    EditText t1;
    TextView tv;
    dbHandler g=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        t1=findViewById(R.id.editTextNumber2);
        tv=findViewById(R.id.tres);
    }
    public void  searchdata(View view){
        g=new dbHandler(this);
       Cursor result= g.getdata(t1.getText().toString());
        while (result.moveToNext()){
            tv.setText(result.getString(1) +" \n"+result.getString(2)+"\n"+result.getString(3)+"\n"+result.getString(4));
        }
    }
}