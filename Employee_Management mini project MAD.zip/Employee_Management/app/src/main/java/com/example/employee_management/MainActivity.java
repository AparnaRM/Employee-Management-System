package com.example.employee_management;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText email,password;
    Button login;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        email=(EditText) findViewById(R.id.editTextTextEmailAddress);
        password=(EditText) findViewById(R.id.editTextTextPassword);
        login=findViewById(R.id.button5);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email1 = email.getText().toString();
                String password1 = password.getText().toString();
                if (email1.equals("") || password1.equals("")){
                    Toast.makeText(MainActivity.this, "Enter all the fields", Toast.LENGTH_LONG).show();
                }
                else
                {
                    if(email1.equals("aparna@gmail.com")&&password1.equals("aparna@123"))
                    {
                        Toast.makeText(MainActivity.this, "LOGIN SUCCESSFUL", Toast.LENGTH_LONG).show();
                        Intent i=new Intent(MainActivity.this,Employee.class);
                        startActivity(i);
                    }
                    else if(email1.equals("ananya@gmail.com")&&password1.equals("ananya@123")) {

                        Toast.makeText(MainActivity.this, "LOGIN SUCCESSFUL", Toast.LENGTH_LONG).show();
                        Intent i=new Intent(MainActivity.this,Employee.class);
                        startActivity(i);

                    }
                    else{
                        Toast.makeText(MainActivity.this, "LOGIN FAILED", Toast.LENGTH_LONG).show();
                    }

                }


            }
        });


    }
}

