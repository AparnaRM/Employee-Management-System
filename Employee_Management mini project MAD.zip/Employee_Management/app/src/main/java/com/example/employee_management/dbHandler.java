package com.example.employee_management;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dbHandler extends SQLiteOpenHelper {
    private static final String dbname = "employee_details.db";

    public dbHandler(@Nullable Context context) {

        super(context, dbname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String q = "create table users(eid integer primary key,name text,designation text,salary integer,phone integer)";
        db.execSQL(q);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists users");
        onCreate(db);
    }
    public boolean insert_data(String eid,String name,String designation,String salary,String phone){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues c=new ContentValues();
        c.put("eid",eid);
        c.put("name",name);
        c.put("designation",designation);
        c.put("salary",salary);
        c.put("phone",phone);
        long r=db.insert("users",null,c);
        if(r==-1)
            return false;
        else
            return true;
    }
    public Cursor getInfo()
    {
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cursor=db.rawQuery("select*from users",null);
        return cursor;
    }
    public boolean delete_data(String eid)
    {
        SQLiteDatabase db=this.getWritableDatabase();

        Cursor cursor=db.rawQuery("select*from users where eid=?",new String[]{eid});
        if(cursor.getCount()>0){
            long r=db.delete("users","eid=?",new String[]{eid});
            if(r==-1)
                return false;
            else
                return true;

        }
        else
            return false;

    }
    public boolean update_data(String eid,String name,String designation,String salary,String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues c = new ContentValues();
        c.put("eid", eid);
        c.put("name", name);
        c.put("designation", designation);
        c.put("salary", salary);
        c.put("phone", phone);
        Cursor cursor = db.rawQuery("select*from users where eid=?", new String[]{eid});
        if (cursor.getCount() > 0) {
            long r = db.update("users", c, "eid=?", new String[]{eid});
            if (r == -1)
                return false;
            else
                return true;

        } else
            return false;

    }
   public Cursor getdata(String eid){
        SQLiteDatabase db=this.getWritableDatabase();
       Cursor cursor = db.rawQuery("select*from users where eid=?", new String[]{eid});
       return  cursor;
   }
}

