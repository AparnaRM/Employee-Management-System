package com.example.employee_management;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;

import android.widget.Button;
import android.widget.EditText;

import android.widget.Toast;



public class Employee extends AppCompatActivity {
    Button b1, b2, b3, b4,b5,b6;
    EditText e1, e2,e3,e4,e5;
    dbHandler g;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee);

        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        b5= findViewById(R.id.button6);
        b6=findViewById(R.id.button7);

        e1 = findViewById(R.id.editTextNumber3);
        e2 = findViewById(R.id.editTextTextPersonName);
        e3= findViewById(R.id.editTextTextPersonName2);
        e4= findViewById(R.id.editTextNumber);
        e5=findViewById(R.id.editTextTextEmailAddress);


        g = new dbHandler(this);



        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String eid1 = e1.getText().toString();
                String name1 = e2.getText().toString();
                String designation1 = e3.getText().toString();
                String salary1 = e4.getText().toString();
                String phone1= e5.getText().toString();
                if (eid1.equals("") || name1.equals("")||designation1.equals("")||salary1.equals("")||phone1.equals("")){
                    Toast.makeText(Employee.this, "Enter all the fields", Toast.LENGTH_LONG).show();
                }
                else {
                    boolean i = g.insert_data(eid1, name1, designation1,salary1,phone1);
                    if (i==true) {
                        Toast.makeText(Employee.this, "Data Inserted successfully", Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(Employee.this, "New entry not inserted", Toast.LENGTH_LONG).show();
                    }
                }

            }

        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor t = g.getInfo();
                if (t.getCount() == 0) {
                    Toast.makeText(Employee.this, "No data found", Toast.LENGTH_LONG).show();
                }
                StringBuffer buffer = new StringBuffer();
                while (t.moveToNext()) {
                    buffer.append("eid: " + t.getString(0) + "\n");
                    buffer.append("name: " + t.getString(1) + "\n");
                    buffer.append("designation: " + t.getString(2) + "\n");
                    buffer.append("salary: " + t.getString(3) + "\n");
                    buffer.append("phone: "+t.getString(4)+"\n\n\n");
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(Employee.this);
                builder.setCancelable(true);
                builder.setTitle("Employee details");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String eid = e1.getText().toString();
                boolean i = g.delete_data(eid);
                if (i == true) {
                    Toast.makeText(Employee.this, "Data deleted successfully", Toast.LENGTH_LONG).show();

                } else
                    Toast.makeText(Employee.this, "Entry not deleted", Toast.LENGTH_LONG).show();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String eid1 = e1.getText().toString();
                String name1 = e2.getText().toString();
                String designation1 = e3.getText().toString();
                String salary1 = e4.getText().toString();
                String phone1=e5.getText().toString();
                boolean i = g.update_data(eid1, name1,designation1,salary1,phone1);
                if (i == true) {
                    Toast.makeText(Employee.this, "Entry updated successfully", Toast.LENGTH_LONG).show();

                } else
                    Toast.makeText(Employee.this, "New entry not updated", Toast.LENGTH_LONG).show();
            }

        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Employee.this,search.class));
            }
        });

        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Employee.this, "Logout Successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Employee.this,MainActivity.class));

            }
        });


    }
}